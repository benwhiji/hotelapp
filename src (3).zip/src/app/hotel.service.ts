import { Injectable } from '@angular/core';
import {BehaviorSubject} from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class HotelService {
  private content = new BehaviorSubject<string>("new name");
  public sharwe = this.content.asObservable();
    private contentb = new BehaviorSubject<string>("new name");
  public sharwb = this.contentb.asObservable();

  constructor() { }
  updatete(text)
  {


    this.content.next(text);
  }
  updatee(email)
  {
	  this.contentb.next(email);
  }
  
}
