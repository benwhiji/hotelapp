import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-checkin',
  templateUrl: './checkin.component.html',
  styleUrls: ['./checkin.component.css']
})
export class CheckinComponent implements OnInit {
   addCreditCard = false;
  constructor() { }

  ngOnInit(): void {
  }
  
  addCreditCardBtn() {
    this.addCreditCard = !this.addCreditCard;
  }
  getToday(): string {
    return new Date().toISOString().split('T')[0]
 }  

}
